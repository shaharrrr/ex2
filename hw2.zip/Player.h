#ifndef HW2_PLAYER_H
#define HW2_PLAYER_H
#include <string>

class Player {
    std::string m_name;
    int m_level;
    int m_force;
    int m_maxHP;
    int m_HP;
    int m_coins;

public:
    static const int MAX_LEVEL = 10;
    static const int DEFAULT_MAX_HP = 100;
    static const int DEFAULT_FORCE = 5;

    /*
     * C'tor of Player class
     *
     * @param name - The name of the player.
     * @param max_HP - The max value of the player's HP.
     * @param force - The initial force of the player.
     * @return
     *      A new instance of Player.
     */
    explicit Player(const std::string& name, int maxHp = DEFAULT_MAX_HP, int force = DEFAULT_FORCE);

    /*
     * C'tor to the "default player" - Player with default name ""
    */
    Player(): m_name(std::string("")),
    m_level(1),
    m_force(DEFAULT_FORCE),
    m_maxHP(DEFAULT_MAX_HP),
    m_HP(DEFAULT_MAX_HP),
    m_coins(0) {}

    /*
     *   Here we are explicitly telling the compiler to use the default methods
     */
    Player(const Player&) = default;
    ~Player() = default;
    Player& operator=(const Player& other) = default;

    /*
     * Prints the player's info on the screen.
     * @return
     *      void.
     */
    void printInfo() const;

    /*
     * Increasing the player's level by 1, if the current level is MAX_LEVEL - does nothing.
     * @return
     *      void.
     */
    void levelUp();

    /*
     * Returns the players' current level.
     * @return
     *      the player's level.
     */
    int getLevel() const;

    /*
     * Increasing the players' force by a given value.
     * @param increaseBy - the value by which the force is increased.
     * @return
     *      void.
     */
    void buff(int increaseBy);

    /*
     * Increasing the players' HP by a given value.
     * @param - increaseBy the value by which the HP is increased.
     * @return
     *      void.
     */
    void heal(int increaseBy);

    /*
     * Decreasing the players' HP by a given value.
     * @param decreaseBy - the value by which the HP is decreased.
     * @return
     *      void.
     */
    void damage(int decreaseBy);

    /*
     * Checks if the player's HP is 0.
     * @return
     *      true - if the players' HP is 0.
     *      false - else.
     */
    bool isKnockedOut() const;

    /*
     * Increasing the players' coins by a given value.
     * @param increaseBy - the value by which the coins are increased.
     * @return
     *      void.
     */
    void addCoins(int increaseBy);

    /*
     * If the player has enough coins, decreasing the players' coins by a given value.
     * @param decreaseBy - the value by which the coins are decreased.
     * @return
     *      true - if the payment was successful (the player had enough coins).
     *      false - else.
     */
    bool pay(int decreaseBy);

    /*
     * Returns the strength of the player's attack (level + force)
     * @return
     *      the strength of the player's attack.
     */
    int getAttackStrength() const;
};


#endif //HW2_PLAYER_H
