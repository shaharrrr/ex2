#include "Mtmchkin.h"


Mtmchkin::Mtmchkin(const char* playerName, const Card* cardsArray, int numOfCards){
    m_status = GameStatus::MidGame;
    Player player(playerName);
    m_player = player;

    m_cards = new Card[numOfCards]();

    for (int i = 0; i < numOfCards; ++i){
        m_cards[i] = cardsArray[i];
    }

    m_currentCard = 0;
    m_numOfCards = numOfCards;
}

Mtmchkin::~Mtmchkin() {
    delete[] m_cards;
}

Mtmchkin::Mtmchkin(const Mtmchkin& game):
    m_status(game.getGameStatus()),
    m_player(game.m_player),
    m_cards(new Card[game.m_numOfCards]),
    m_currentCard(game.m_currentCard),
    m_numOfCards(game.m_numOfCards)
{
    for (int i = 0; i < this->m_numOfCards; ++i) {
        this->m_cards[i] = game.m_cards[i];
    }
}

Mtmchkin& Mtmchkin::operator=(const Mtmchkin& other){
    if (this == &other){
        return *this;
    }

    m_status = other.getGameStatus();
    m_player = other.m_player;

    Card* newCards = new Card[other.m_numOfCards];
    for (int i = 0; i < other.m_numOfCards; ++i) {
        newCards[i] = other.m_cards[i];
    }
    delete[] this->m_cards;
    m_cards = newCards;

    m_currentCard = other.m_currentCard;
    m_numOfCards = other.m_numOfCards;

    return *this;
}

GameStatus Mtmchkin::getGameStatus() const{
    return m_status;
}

void Mtmchkin::playNextCard(){
    if (m_status != GameStatus::MidGame){
        return;
    }

    m_cards[m_currentCard].printInfo();
    m_cards[m_currentCard].applyEncounter(m_player);
    m_player.printInfo();

    if (m_currentCard == m_numOfCards - 1){
        m_currentCard = 0;
    }

    else{
        m_currentCard += 1;
    }

    updateStatus();
}

void Mtmchkin::updateStatus(){
    if (m_player.isKnockedOut()){
        m_status = GameStatus::Loss;
    }

    else if (m_player.getLevel() == Player::MAX_LEVEL){
        m_status = GameStatus::Win;
    }
}

bool Mtmchkin::isOver(){
    if (m_status == GameStatus::Win || m_status == GameStatus::Loss){
        return true;
    }

    else{
        return false;
    }
}