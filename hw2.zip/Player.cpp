#include "Player.h"
#include "utilities.h"

Player::Player(const std::string& name, int maxHP, int force){
    m_name = name;
    m_level = 1;

    if (force > 0){
        m_force = force;
    }

    else{
        m_force = DEFAULT_FORCE;
    }

    if (maxHP > 0){
        m_maxHP = maxHP;
    }

    else{
        maxHP = DEFAULT_MAX_HP;
    }

    m_HP = m_maxHP;
    m_coins = 0;
}

void Player::printInfo() const{
    printPlayerInfo(m_name.c_str(), m_level, m_force, m_HP, m_coins);
}

void Player::levelUp(){
    if (m_level < MAX_LEVEL){
        ++m_level;
    }
}

int Player::getLevel() const {
    return m_level;
}

void Player::buff(int increaseBy) {
    if (increaseBy > 0){
        m_force += increaseBy;
    }
}

void Player::heal(int increaseBy) {
    if (increaseBy > 0){
        if (m_HP + increaseBy > m_maxHP){
            m_HP = m_maxHP;
        }

        else{
            m_HP += increaseBy;
        }
    }
}

void Player::damage(int decreaseBy) {
    if (decreaseBy > 0){
        if (m_HP - decreaseBy < 0){
            m_HP = 0;
        }

        else{
            m_HP -= decreaseBy;
        }
    }
}

bool Player::isKnockedOut() const {
    if (m_HP == 0){
        return true;
    }

    return false;
}

void Player::addCoins(int increaseBy) {
    if (increaseBy > 0){
        m_coins += increaseBy;
    }
}

bool Player::pay(int decreaseBy) {
    if (m_coins < decreaseBy){
        return false;
    }

    if (decreaseBy > 0){
        m_coins -= decreaseBy;
    }

    return true;
}

int Player::getAttackStrength() const {
    return (m_level + m_force);
}
